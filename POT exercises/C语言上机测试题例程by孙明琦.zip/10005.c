#include <stdio.h>

int main(void){
	printf("Programming in C is fun!\n");
	return 0;
}
