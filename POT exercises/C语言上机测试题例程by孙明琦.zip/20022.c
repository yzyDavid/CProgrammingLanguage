#include <stdio.h>

int main(void){
	int f;
	scanf("%d", &f);
	
	printf("celsius = %d\n", 5 * (f - 32) / 9);
	return 0;
}