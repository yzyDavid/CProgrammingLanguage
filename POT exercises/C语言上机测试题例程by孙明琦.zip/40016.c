#include <stdio.h>
#define ABS(x) ((x) > 0) ? (x) : -(x)

int digiCount(int num);
int digiSum(int num);
int main(void){
	int rep;
	for (scanf("%d", &rep); rep > 0; --rep){
		int num;
		scanf("%d", &num);
		printf("count = %d, sum = %d\n", digiCount(num), digiSum(num));
	}
	return 0;
}

int digiCount(int num){
	num = ABS(num);
	if (num / 10 == 0){
		return 1;
	}
	else {
		return digiCount(num / 10) + 1;
	}
}

int digiSum(int num){
	num = ABS(num);
	if (num / 10 == 0){
		return num;
	}
	else {
		return num % 10 + digiSum(num / 10);
	}
}
